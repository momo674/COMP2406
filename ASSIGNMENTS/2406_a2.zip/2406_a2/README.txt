NAME: Momo Radaideh 101292701
LAUNCH INSTRUCTIONS: run `node server.js` in \2406_a2 directory.
TESTTING INSTRUCTIONS: vist `http://localhost:3000/index.html` in Chrome